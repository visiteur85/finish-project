import React from 'react';

export const SetPassword = () => {
    return (
        <div>
            Set Password
        </div>
    );
};

