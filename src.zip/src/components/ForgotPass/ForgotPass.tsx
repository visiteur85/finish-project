import React from 'react';

export const ForgotPass = () => {
    return (
        <div>
            Forgot your password
        </div>
    );
};
