import React from 'react';

export const Registration = () => {
    return (
        <div>
            REGISTRATION
        </div>
    );
};

