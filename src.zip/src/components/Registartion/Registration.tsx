import React from 'react';
import {Register} from "../LoginNew/Register";

export const Registration = () => {
    return (
        <div>
            REGISTRATION
            <Register/>
        </div>
    );
};

