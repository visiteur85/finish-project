import React from 'react';

export const PageNotFound = () => {
    return (

            <h1>PAGE NOT FOUND 404</h1>

    );
};
